A Pen created at CodePen.io. You can find this one at https://codepen.io/rachsmith/pen/IsixL.

 I wanted to make something to tesst out Sass directives so I created this full screen nav animate in/out with the Sass @for directive.

At the moment the sizing is a bit wack on mobile - something to do with window.innerHeight not getting the mobile viewport size